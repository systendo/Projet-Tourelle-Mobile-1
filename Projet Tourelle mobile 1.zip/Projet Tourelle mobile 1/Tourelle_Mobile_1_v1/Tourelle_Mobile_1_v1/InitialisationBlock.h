///  Prototype de la fonction InitialisationBlock. 
Block InitialisationBlock (Block) ;

///  Prototype de la fonction ValeurBlockDroit. 
Block ValeurBlockDroit(Block) ;

///  Prototype de la fonction ValeurBlockGauche. 
Block ValeurBlockGauche(Block) ;

///  Prototype de la fonction EnvoiBlock. 
void EnvoiBlock(Block);