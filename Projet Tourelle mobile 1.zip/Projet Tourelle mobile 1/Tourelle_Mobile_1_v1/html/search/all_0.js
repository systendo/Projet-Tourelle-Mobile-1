var searchData=
[
  ['affichage',['affichage',['../affichage_8c.html#ac75fddfa24e492ba1b34bdc83d49478b',1,'affichage(int signature_aff, int x_aff_gauche, int y_aff_gauche, int x_aff_droite, int y_aff_droite):&#160;affichage.c'],['../affichage_8h.html#ac75fddfa24e492ba1b34bdc83d49478b',1,'affichage(int signature_aff, int x_aff_gauche, int y_aff_gauche, int x_aff_droite, int y_aff_droite):&#160;affichage.c']]],
  ['affichage_2ec',['affichage.c',['../affichage_8c.html',1,'']]],
  ['affichage_2eh',['affichage.h',['../affichage_8h.html',1,'']]]
];
