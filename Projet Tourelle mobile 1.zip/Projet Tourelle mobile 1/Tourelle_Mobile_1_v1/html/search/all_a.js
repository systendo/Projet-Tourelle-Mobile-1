var searchData=
[
  ['signature',['signature',['../struct_block.html#ab2914a69436eb03ddb2a13fbf7ddcfad',1,'Block']]]
];
